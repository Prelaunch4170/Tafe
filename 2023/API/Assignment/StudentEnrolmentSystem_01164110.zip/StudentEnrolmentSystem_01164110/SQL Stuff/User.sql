create user "StudentEnrole"@"localhost" identified by "Password";
GRANT ALL ON *.* TO 'StudentEnrole'@'localhost' WITH GRANT OPTION;